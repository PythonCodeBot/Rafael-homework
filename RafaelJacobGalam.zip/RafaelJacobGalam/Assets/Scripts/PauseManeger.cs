﻿using UnityEngine;

public class PauseManeger : MonoBehaviour
{
    public UnityEngine.UI.Text buttonText;

    private float startTime;
    private bool isRun;
    private string runMsg = "Pause";
    private string stopMsg = "Start";

    private void Start()
    {
        startTime = Time.timeScale;
        isRun = true;
        ChangePauseText();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            OnPressStartOrPause();
        }
    }

    private void ChangePauseText()
    {
        if (isRun)
        {
            buttonText.text = runMsg;
        }
        else
        {
            buttonText.text = stopMsg;
        }
    }

    public void OnPressStartOrPause()
    {
        if (isRun)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = startTime;
        }
            
        isRun = !isRun;
        ChangePauseText();
    }
}
