﻿using UnityEngine;

[ExecuteInEditMode]
public class FilterCamera : MonoBehaviour
{
    public Material MatFilter;

    private void Start()
    {
        GetComponent<Camera>().depthTextureMode = DepthTextureMode.Depth;
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (MatFilter != null)
            Graphics.Blit(source, destination, MatFilter);
        else
            Graphics.Blit(source, destination);
    }
}
