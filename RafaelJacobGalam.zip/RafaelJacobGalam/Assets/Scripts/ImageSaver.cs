﻿using UnityEngine;
using System.IO;

public class ImageSaver : MonoBehaviour
{
    public Camera TargetCamera;

    private RenderTexture CameraRenderTexture;
    private int FileCounter = 0;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            SaveImage();
        }
    }

    private Texture2D RTImage(Camera mCamera)
    {
        int Width = mCamera.pixelWidth;
        int Height = mCamera.pixelHeight;
        Rect rect = new Rect(0, 0, mCamera.pixelWidth, mCamera.pixelHeight);
        RenderTexture renderTexture = new RenderTexture(Width, Height, 24);
        Texture2D screenShot = new Texture2D(Width, Height, TextureFormat.RGBA32, false);

        mCamera.targetTexture = renderTexture;
        mCamera.Render();

        RenderTexture.active = renderTexture;
        screenShot.ReadPixels(rect, 0, 0);

        mCamera.targetTexture = null;
        RenderTexture.active = null;

        Destroy(renderTexture);
        renderTexture = null;
        return screenShot;
    }

    public void SaveImage()
    {
        var texture = RTImage(TargetCamera);


        var Bytes = texture.EncodeToPNG();


        string fileName = FileCounter.ToString("D3");
        string savePath = $"{Application.dataPath}/Frame__{fileName}.png";
        Debug.Log($"Save image in \"{savePath}\"");
        File.WriteAllBytes(savePath, Bytes);
        FileCounter++;
    }
}
