﻿using UnityEngine;

public class UpdateHeightText : MonoBehaviour
{
    public Transform ball;
    public UnityEngine.UI.Text UIText;

    // Update is called once per frame
    private void Update()
    {
        var Height = ball.position.y;
        var roundedHeight = Height.ToString("F2");
        UIText.text = $"Height = {roundedHeight}";
    }
}
